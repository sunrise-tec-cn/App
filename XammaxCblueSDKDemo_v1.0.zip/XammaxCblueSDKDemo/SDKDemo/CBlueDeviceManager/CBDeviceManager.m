//
//  CBDeviceManager.m
//  sunriseTecBleSdk
//
//  Created by Rosa on 2017/6/29.
//  Copyright © 2017年 启昇电子科技. All rights reserved.
//

#import "CBDeviceManager.h"
#import "CommProtocolDmhc1v5.h"

static NSString *const CBlueDeviceManagerDefaultPeripheralId = @"CBlueDeviceManagerDefaultPeripheralId";


@implementation CBDeviceManager

+ (instancetype)getInstance {
    static id _instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[self alloc] init];
    });
    return _instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        [self mCBDevice];
    }
    return self;
}

#pragma mark - CBlueDeviceDelegate
/*!
 *  @method foundPeripheral:advertisementData:
 *
 *  @param peripheral 蓝牙设备对象
 *  @param advertisementData 包含蓝牙设备广播信息或者蓝牙搜索回应数据的字典容器。
 *
 *  @abstract 搜索蓝牙时返回的蓝牙设备信息。
 *
 *  @discussion 请及时保存<i>peripheral</i>引用，系统随时可能将其释放。
 *
 *  @seealso scanStart
 */
-(void)foundPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData
{
    [self.foundedPeripherals setObject:peripheral forKey:peripheral.identifier.UUIDString];
    
//    NSLog(@"foundPeripheral:%@",peripheral.name);
//    NSLog(@"foundedPeripherals:%@", self.foundedPeripherals);
    
    NSString *defaultPeripheralId = [StorageHelper appInfoForKey:CBlueDeviceManagerDefaultPeripheralId];
    
    if ([defaultPeripheralId isEqualToString:peripheral.identifier.UUIDString]) {
        if (peripheral.state == CBPeripheralStateConnected) {
            
        } else {
            [self.mCBDevice connect:peripheral];            
        }
    }
    else{
        [self.mCBDevice connect:peripheral];
    }
}
/*!
 *  @method connectedPeripheral:
 *
 *  @param peripheral 蓝牙设备对象
 *
 *  @abstract 连接蓝牙时返回已经连接上的蓝牙设备信息。
 *
 *  @seealso connect:
 */
-(void)connectedPeripheral:(CBPeripheral*) peripheral
{
    NSLog(@"connected");
    [StorageHelper setAppInfo:peripheral.identifier.UUIDString forKey:CBlueDeviceManagerDefaultPeripheralId];
    self.mCBConnectedPeripheral = peripheral;
    
    self.cbGloableManager = [[CBlueGloableManager alloc] initWithConnector:self.mCBDevice];
    self.mCBGloable = [self.cbGloableManager getGlobalManager:self];
}
/*!
 *  @method disconnectedPeripheral:
 *
 *  @param peripheral 蓝牙设备对象
 *
 *  @abstract 断开蓝牙时返回已经断开的蓝牙设备信息。
 *
 *  @seealso disconnect:
 */
-(void)disconnectedPeripheral:(CBPeripheral*) peripheral
{
    
    [self.mCBDevice scanStart];
}
/*!
 *  @method disconnectedPeripheral:initiative:
 *
 *  @param peripheral 蓝牙设备对象
 *  @param onInitiative 是否用户主动断开连接
 *
 *  @abstract 断开蓝牙时返回已经断开的蓝牙设备信息。
 *
 *  @seealso disconnect:
 */
-(void)disconnectedPeripheral:(CBPeripheral*) peripheral initiative:(BOOL)onInitiative
{
    if (!onInitiative)
    {
        NSLog(@"disconnected Peripheral unexpectedly");
        [self.mCBDevice scanStart];
    }
}
#pragma mark - CBlueGloableDelegate
/*!
 *  @method managerReady
 *
 *  @abstract Device has been handshake and synced with App. Reday for other process
 */
-(void)managerReady
{
    NSLog(@"managerReady");
}
/*!
 *  @method isDeviceHwVersion:swVersion:
 *
 *  @param sVer 待同步的设备硬件版本
 *
 *  @param hVer 待同步的设备软件版本
 *
 *  @abstract 同步设备版本号
 */
-(void)isDeviceHwVersion:(NSData *)sVer swVersion:(NSData *)hVer
{
}
/*!
 *  @method setSystemTime:
 *
 *  @param time 待同步的系统时间及日期。可以为nil，为nil时自动同步iOS Device当前时间
 *
 *  @abstract 同步指定时间和日期到设备端
 */
-(void)setSystemTime:(NSDate *)time
{

}
/*!
 *  @method isAssistChanged
 *
 *  @param value 设备当前的Assist值
 *
 *  @abstract 收到此回调表示设备Assist值更新，同步给App做对应处理
 */
-(void)isDeviceBatteryPowerUpdated:(UInt8)value
{
    
}
/*!
 *  @method isDeviceIntervalMileageUpdated
 *
 *  @param recordDic 设备记录的区间里程，字典类型数据，Key:NSDate类型的区间时间；Object:Uint8类型的里程值
 *
 *  @abstract 收到此回调表示设备Assist值更新，同步给App做对应处理
 */
-(void)isDeviceIntervalMileageUpdated:(NSMutableDictionary *)recordDic
{
    NSLog(@"%s, %d", __FUNCTION__, __LINE__);

    NSLog(@"IntervalMileage:%@", recordDic);
}
/*!
 *  @method isAssistChanged
 *
 *  @param value 设备当前的Assist值
 *
 *  @abstract 收到此回调表示设备Assist值更新，同步给App做对应处理
 */
-(void)isAssistChanged:(UInt8)value
{
    [self.delegate isAssistValueChanged:value];
}
/*!
 *  @method isDeviceSupportOTA
 *
 *  @abstract 收到此回调表示设备支持OTA升级功能，UI层做相应显示或功能处理
 */
-(void)isDeviceSupportOTA
{

}
/*!
 *  @method isBuildInPacket:withVersion:
 *
 *  @param ver BuildIn协议的版本，用来匹配对应的通讯协议
 *
 *  @param packet BuildIn协议的全部内容，用来解析、处理
 *
 *  @abstract 输出全部的内嵌协议内容，供上层提取有用数据. 版本VER_DMHC_1_5对应协议参考：CommProtocolDmhc1v5.h
 */
-(void)isBuildInPacket:(NSData *)packet withVersion:(BUILD_IN_VER)ver
{
    NSLog(@"buildinPacket = %@", packet);
    
    if (ver == VER_DMHC_1_5)
    {
        uart_rx_packet cmdPkt;
        memcpy(&cmdPkt, [packet bytes], RX_DATA_LEN);
        
        [self.delegate isBuildInPacketUpdated:packet];
        
        UInt16 speed = (cmdPkt.speed_h<<8)|cmdPkt.speed_l;
        [self.delegate isSpeedValueChanged:speed];
    }
}


#pragma mark - Getter
- (CBlueDevice *)mCBDevice {
    if (!_mCBDevice) {
        NSLog(@"mCBDevice init");
        _mCBDevice = [[CBlueDevice alloc] init];
        [_mCBDevice initCBlueDevice];
        [_mCBDevice setCBlueDeviceDelegate:self];
        [_mCBDevice setAppForeground:YES];
    }
    return _mCBDevice;
}

- (NSMutableDictionary<NSString*, CBPeripheral*> *) foundedPeripherals {
    if (!_foundedPeripherals) {
        _foundedPeripherals = [NSMutableDictionary new];
    }
    return _foundedPeripherals;
}
@end
