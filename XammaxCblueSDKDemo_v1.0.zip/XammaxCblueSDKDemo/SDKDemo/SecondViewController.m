//
//  SecondViewController.m
//  XammaxShifterSDKDemo
//
//  Created by Rosa on 2017/6/24.
//  Copyright © 2017年 启昇电子科技. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // Initialize BLE
    [CBDeviceManager getInstance];
    [CBDeviceManager getInstance].delegate = self;
    
    // 结合fingerTapped完成点击空白处收起键盘
    self.view.userInteractionEnabled = YES;
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fingerTapped:)];
    [self.view addGestureRecognizer:singleTap];
    
    _sliderAssist.minimumValue = 0;
    _sliderAssist.maximumValue = 4;
    _sliderAssist.continuous = NO;
    
    _textSendData.placeholder = @"input hex data.";
    
    // 弹出键盘则上推视图
    _textFildRevData.delegate = self;
    _textSendData.delegate = self;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)fingerTapped:(UITapGestureRecognizer *)gestureRecognizer
{
    [self.view endEditing:YES];
}


- (IBAction)btnSendData:(id)sender {
    DataConvert *cvt=[[DataConvert alloc]init];
    NSData *textData = [cvt stringToHexData:_textSendData.text];
    
//    [[CBDeviceManager getInstance].mCBDevice bleWriteData:textData];
    [[CBDeviceManager getInstance].mCBGloable sendBlePktWithCmd:CMD_DEVICE_FULL_MILEAGE withOpcode:OPC_REQ withData:textData];
}

- (IBAction)sliderAssist:(id)sender {
    UISlider *assist = sender;
    
    if (assist.value<1)//0.2)
    {
        assist.value = 0;
        _lableAssistValue.text  = @"1";
    }
    else if (assist.value>=1 && assist.value<2)//>=0.2 && assist.value<0.4)
    {
        assist.value = 1;//0.25;
        _lableAssistValue.text  = @"2";
    }
    else if (assist.value>=2 && assist.value<3)//>=0.4 && assist.value<0.6)
    {
        assist.value = 2;//0.5;
        _lableAssistValue.text  = @"3";
    }
    else if (assist.value>=3 && assist.value<4)//>=0.6 && assist.value<0.8)
    {
        assist.value = 3;//0.75;
        _lableAssistValue.text  = @"4";
    }
    else
    {
        assist.value = 4;//1;
        _lableAssistValue.text  = @"5";
    }
    if (_sliderAssist.value == 0x01 || _sliderAssist.value == 0x02 || _sliderAssist.value == 0x03 || _sliderAssist.value == 0x04 || _sliderAssist.value == 0x05)
        [[CBDeviceManager getInstance].mCBGloable setDeviceAssistValue:assist.value];
    _sliderAssist.value = assist.value;
}

-(void)isAssistValueChanged:(UInt8)value
{
    _sliderAssist.value = value;
    _lableAssistValue.text = [NSString stringWithFormat:@"%d", value];
}

-(void)isSpeedValueChanged:(UInt16)value
{
    _lableSpeedValue.text = [NSString stringWithFormat:@"%f", value*0.1];
}

-(void)isBuildInPacketUpdated:(NSData *)packet
{
    _textFildRevData.text = packet.description;
}
@end

