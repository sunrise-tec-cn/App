//
//  StorageHelper.m
//  basicMethod
//
//  Created by Rosa on 2017/6/24.
//  Copyright © 2017年 启昇电子科技. All rights reserved.
//

#import "StorageHelper.h"

@implementation StorageHelper
+ (void)setAppInfo:(id)value forKey:(NSString *)key {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:value forKey:key];
    [defaults synchronize];
}

+ (id)appInfoForKey:(NSString *)key {
    return [[NSUserDefaults standardUserDefaults] valueForKey:key];
}

+ (void)removeAppInfoForKey:(NSString *)key {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
@end
