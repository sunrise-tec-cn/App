//
//  DataConvert.m
//  basicMethod
//
//  Created by Rosa on 2017/6/22.
//  Copyright © 2017年 启昇电子科技. All rights reserved.
//

#import "DataConvert.h"

@implementation DataConvert

/*!
 *  @method stringToHexData:
 *
 *  @param nsStr NSString that will be covert into hexadecimal
 *
 *  @abstract convert NSString into hexadecimal data as NSData format
 *
 *  @seealso Null
 */
- (NSData *) stringToHexData:(NSString *)nsStr
{
    NSUInteger len = [nsStr length]/2;    // Target length
    unsigned char *buf = malloc(len);
    unsigned char *whole_byte = buf;
    char byte_chars[3] = {'\0','\0','\0'};
    
    int i;
    for (i=0; i < [nsStr length] / 2; i++) {
        byte_chars[0] = [nsStr characterAtIndex:i*2];
        byte_chars[1] = [nsStr characterAtIndex:i*2+1];
        *whole_byte = strtol(byte_chars, NULL, 16);
        whole_byte++;
    }
    
    NSData *data = [NSData dataWithBytes:buf length:len];
    free( buf );
    return data;
}

/*!
 *  @method dataToHexString:
 *
 *  @param data The source data which will be converted!
 *
 *  @abstract convert NSString into hexadecimal data as NSData format
 *
 *  @seealso Null
 */
- (NSString *) dataToHexString:(NSData*)data
{
    NSUInteger          len = [data length];
    char *              chars = (char *)[data bytes];
    NSMutableString *   hexString = [[NSMutableString alloc] init];
    
    for(NSUInteger i = 0; i < len; i++ )
        [hexString appendString:[NSString stringWithFormat:@"%0.2hhx", chars[i]]];
    
    return hexString;
}
@end
