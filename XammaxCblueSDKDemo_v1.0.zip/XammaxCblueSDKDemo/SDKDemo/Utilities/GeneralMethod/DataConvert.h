//
//  dataProcess.h
//  basicMethod
//
//  Created by Rosa on 2017/6/22.
//  Copyright © 2017年 启昇电子科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataConvert : NSObject

/*!
 *  @method stringToHexData:
 *
 *  @param nsStr The source data which will be converted!
 *
 *  @abstract convert NSString into hexadecimal data as NSData format
 *
 *  @seealso Null
 */
- (NSData *) stringToHexData:(NSString *)nsStr;

/*!
 *  @method dataToHexString:
 *
 *  @param data The source data which will be converted!
 *
 *  @abstract convert NSString into hexadecimal data as NSData format
 *
 *  @seealso Null
 */
- (NSString *) dataToHexString:(NSData*)data;

@end
