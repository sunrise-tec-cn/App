//
//  CommProtocolData.h
//  sunriseTecBleSdk
//
//  Created by 白蓉 on 2017/6/29.
//  Copyright © 2017年 SunriseTechnology. All rights reserved.
//
#import <Foundation/Foundation.h>

#ifndef CommProtocolData_h
#define CommProtocolData_h

#define SUB_PARAM_INTERVAL_MILEAGE_LEN  9

#define SUB_PARAM_INTERVAL_MILEAGE_ST   4   // USE 4Byte to trans UTCTime   --0712--
//#define SUB_PARAM_INTERVAL_MILEAGE_ST   8   // USE 8Byte to trans UTCTime 

////////////////////////////////////////////////////////////////////////////////////
enum {
    // Common command
    CMD_HANDSHAKE                   =0x00,
    CMD_DEVICE_CAPABILITY           =0x01,
    CMD_DEVICE_SETTINGS             =0x02,
    CMD_DEVICE_TIME_OFFSET          =0x03,
    CMD_DEVICE_REFERENCE_TIME_DATE  =0x04,
    CMD_DEVICE_VERSION              =0x05,

    // Shifter Usage
    CMD_DEVICE_BATTERY_POWER        =0x11,
    CMD_DEVICE_INTERVAL_MILEAGE     =0x12,
    CMD_DEVICE_FULL_MILEAGE         =0x13,
    CMD_DEVICE_ASSIST               =0x14,
 
    CMD_DEVICE_BUILDIN_PACKET       =0xA0,
    
};

typedef struct
{
    NSTimeInterval offsetTime;
    UInt8 distance;
}ST_SUB_PARAM1;

/*!
 *  @enum BUILD_IN_VER
 *
 *  @abstract buildIn命令的版本。
 *
 *  @constant VER_DMHC_1_2  东枚和创通讯协议V1.2版本。
 *
 *  @constant VER_DMHC_1_5  东枚和创通讯协议V1.5版本。
 */
typedef enum {
    VER_DMHC_1_2    =0,
    VER_DMHC_1_5    =1,
    
}BUILD_IN_VER;

/*!
 *  @enum OP_CODE
 *
 *  @abstract 命令类型。
 *
 *  @constant APP  应用切换。
 *  @constant CTL  控制。
 *  @constant QUE  查询。
 *  @constant SET  设置。
 *  @constant ANS  应答。
 *
 */
typedef enum {
    OPC_ERROR       = 0x01,
    OPC_ACK         = 0x02,
    OPC_SYNC        = 0x04, // From device to app to responds of OPC_REQ
    OPC_SET         = 0x08, // From app to device
    OPC_REQ         = 0x10, // From app to device
    OPC_NOTIFY      = 0x20, // From device to app
}OP_CODE;


#endif /* CommProtocolData_h */
