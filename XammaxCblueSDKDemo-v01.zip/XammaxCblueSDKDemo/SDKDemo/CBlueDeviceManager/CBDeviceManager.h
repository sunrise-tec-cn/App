//
//  CBDeviceManager.h
//  sunriseTecBleSdk
//
//  Created by Rosa on 2017/6/29.
//  Copyright © 2017年 启昇电子科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CBlueGloableManager.h"


@protocol CBDeviceDelegate <NSObject>

-(void)isAssistValueChanged:(UInt8)value;
/*!
 *  @method isBuildInSomethingUpdated:
 *
 *  @param value 更新的内容
 *
 *  @abstract 参考对应协议：CommProtocolDmhc1v5.h，计算出需要的内容
 *
 *  @seealso isSpeedValueChanged:
 */
-(void)isBuildInSomethingUpdated:(id)value;/*!
 *  @method isSpeedValueChanged:
 *
 *  @param value 当前速度值
 *
 *  @abstract 参考对应协议：CommProtocolDmhc1v5.h，计算出当前速度待UI显示处理
 *
 *  @seealso isBuildInPacketUpdated:
 */
-(void)isSpeedValueChanged:(UInt16)value;
/*!
 *  @method isSpeedValueChanged:
 *
 *  @param packet 内嵌协议数据包内容
 *
 *  @abstract 参考对应协议：CommProtocolDmhc1v5.h，计算出当前速度待UI显示处理
 *
 *  @seealso isSpeedValueChanged:
 */
-(void)isBuildInPacketUpdated:(NSData *)packet;
@end

@interface CBDeviceManager : NSObject<CBlueDeviceDelegate, CBlueGloableDelegate>
@property (nonatomic, strong) CBlueDevice *mCBDevice;

@property (nonatomic, strong) CBlueGloableManager *cbGloableManager;

@property (nonatomic, strong) CBPeripheral *mCBConnectedPeripheral;
@property (nonatomic, strong) NSMutableDictionary<NSString*, CBPeripheral*> *foundedPeripherals;

@property (nonatomic, weak) id<CBDeviceDelegate>delegate;

@property (nonatomic, strong) id<CBlueGloableManager> mCBGloable;


+ (instancetype)getInstance;
- (CBlueDevice *)mCBDevice;

@end
