//
//  StorageHelper.h
//  basicMethod
//
//  Created by Rosa on 2017/6/24.
//  Copyright © 2017年 启昇电子科技. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StorageHelper : NSObject
+ (void)setAppInfo:(id)value forKey:(NSString *)key;
+ (id)appInfoForKey:(NSString *)key;
+ (void)removeAppInfoForKey:(NSString *)key;

@end
