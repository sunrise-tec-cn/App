//
//  SecondViewController.h
//  bleSDK
//
//  Created by 白蓉 on 2017/6/24.
//  Copyright © 2017年 白蓉. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DataConvert.h"

@interface SecondViewController : UIViewController<UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UILabel *lableAssist;
@property (strong, nonatomic) IBOutlet UILabel *lableSpeed;
@property (strong, nonatomic) IBOutlet UILabel *lableTrip;
@property (strong, nonatomic) IBOutlet UILabel *lableRevDatas;
@property (strong, nonatomic) IBOutlet UILabel *lableSendDatas;

@property (strong, nonatomic) IBOutlet UISlider *sliderAssist;
@property (strong, nonatomic) IBOutlet UILabel *lableAssistValue;
@property (strong, nonatomic) IBOutlet UILabel *lableSpeedValue;
@property (strong, nonatomic) IBOutlet UILabel *lableTripValue;

@property (strong, nonatomic) IBOutlet UITextField *textFildRevData;
@property (strong, nonatomic) IBOutlet UITextField *textSendData;

- (IBAction)btnSendData:(id)sender;
- (IBAction)sliderAssist:(id)sender;

@end
