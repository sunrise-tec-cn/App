//
//  CBlueGloableManager.h
//  sunriseTecBleSdk
//
//  Created by Rosa on 2017/7/4.
//  Copyright © 2017年 启昇电子科技. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CBlueDevice.h"
#import "CommProtocolData.h"

////////////////////////////////////////////////////////////////////////////////
/*!
 *  @protocol CommLinkDelegate
 *
 *  @abstract {@link CommLink}对象的代理需遵循 <code>CommLinkDelegate</code>协议.
 */
@protocol CBlueGloableDelegate <NSObject>
@required
/*!
 *  @method managerReady
 *
 *  @abstract Device has been handshake and synced with App. Reday for other process
 */
-(void)managerReady;
/*!
 *  @method isDeviceHwVersion:swVersion:
 *
 *  @param sVer 待同步的设备硬件版本
 *
 *  @param hVer 待同步的设备软件版本
 *
 *  @abstract 同步设备版本号
 */
-(void)isDeviceHwVersion:(NSData *)sVer swVersion:(NSData *)hVer;

@optional
/*!
 *  @method setSystemTime:
 *
 *  @param time 待同步的系统时间及日期。可以为nil，为nil时自动同步iOS Device当前时间
 *
 *  @abstract 同步指定时间和日期到设备端
 */
-(void)setSystemTime:(NSDate *)time;
/*
 */
-(void)isDeviceBatteryPowerUpdated:(UInt8)value;
/*!
 *  @method isDeviceIntervalMileageUpdated
 *
 *  @param recordDic 设备记录的区间里程，字典类型数据，Key:NSDate类型的区间时间；Object:Uint8类型的里程值
 *
 *  @abstract 收到此回调表示设备区间里程值更新，同步给App做对应处理
 */
-(void)isDeviceIntervalMileageUpdated:(NSMutableDictionary *)recordDic;
/*!
 *  @method isDeviceSupportOTA
 *
 *  @abstract 收到此回调表示设备支持OTA升级功能，UI层做相应显示或功能处理
 */
-(void)isDeviceSupportOTA;
/*!
 *  @method isAssistChanged
 *
 *  @param value 设备当前的Assist值
 *
 *  @abstract 收到此回调表示设备Assist值更新，同步给App做对应处理
 */
-(void)isAssistChanged:(UInt8)value;
/*!
 *  @method isBuildInPacket:withVersion:
 *
 *  @param ver BuildIn协议的版本，用来匹配对应的通讯协议
 *
 *  @param packet BuildIn协议的全部内容，用来解析、处理
 *
 *  @abstract 输出全部的内嵌协议内容，供上层提取有用数据
 */
-(void)isBuildInPacket:(NSData *)packet withVersion:(BUILD_IN_VER)ver;
@end


/*!
 *  @protocol CBlueGloableManager
 *
 *  @abstract 蓝牙命令控制接口
 */
@protocol CBlueGloableManager <NSObject>
/*!
 *  @method setDeviceAssistValue:
 *
 *  @param value 通过App调节的Assist值
 *
 *  @abstract 蓝牙命令控制接口，用于App设置设备的Assist值
 */
-(void)setDeviceAssistValue:(UInt8)value;
/*!
 *  @method reqDeviceVersion
 *
 *  @abstract 蓝牙命令控制接口，用于App获取设备的版本值
 */
-(void)reqDeviceVersion;
/*!
 *  @method reqDeviceReferenceTimeCounter
 *
 *  @abstract 蓝牙命令控制接口，用于App获取设备的参考时钟
 */
-(void)reqDeviceReferenceTimeCounter;
/*!
 *  @method reqDeviceTimeCounter
 *
 *  @abstract 蓝牙命令控制接口，用于App获取设备的当前时钟
 */
-(void)reqDeviceTimeCounter;
/*!
 *  @method reqDeviceIntervalMileage
 *
 *  @abstract 蓝牙命令控制接口，用于App获取设备的区间里程
 */
-(void)reqDeviceIntervalMileage;
/*!
 *  @method sendBlePktWithCmd:withOpcode:withData:
 *
 *  @param cmd 协议命令
 *
 *  @param opcode 协议操作码
 *
 *  @param wData 协议内容
 *
 *  @abstract 用于向设备发送协议数据包
 */
- (NSData *)sendBlePktWithCmd:(UInt8)cmd withOpcode:(OP_CODE)opcode withData:(NSData *)wData;
/*!
 *  @method sendBlePktWithCmd:withOpcode:withByte:withLen:
 *
 *  @param cmd 协议命令
 *
 *  @param opcode 协议操作码
 *
 *  @param bytes 协议内容
 *
 *  @param length 协议内容长度
 *
 *  @abstract 用于向设备发送协议数据包
 */
- (NSData *)sendBlePktWithCmd:(UInt8)cmd withOpcode:(OP_CODE)opcode withByte:(UInt8 *)bytes withLen:(UInt8)length;
@end

@interface CBlueGloableManager : NSObject
/*!
 *  @method initWithConnector:
 *
 *  @param connector 远程连接设备{@link CBlueDevice}
 *
 *  @return 类对象
 *
 *  @abstract 构造函数
 */
-(id)initWithConnector:(CBlueDevice *)connector;
/*!
 *  @method getGlobalManager:
 *
 *  @param delegate GlobalManager协议
 *
 *  @return 全局管理对象
 *
 *  @abstract 获取{@link CBlueGloableManager}全局管理对象
 */
-(id<CBlueGloableManager>)getGlobalManager:(id<CBlueGloableDelegate>)delegate;

@end
