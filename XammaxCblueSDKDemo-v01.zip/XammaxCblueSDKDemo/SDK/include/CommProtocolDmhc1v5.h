//
//  CommProtocolDmhc1v5.h
//  sunriseTecBleSdk
//
//  Created by Rosa on 2017/7/3.
//  Copyright © 2017年 启昇电子科技. All rights reserved.
//
#import <Foundation/Foundation.h>

#ifndef CommProtocolDmhc1v5_h
#define CommProtocolDmhc1v5_h

//TX STRUCTURE ////////////////////////////////////////////////////
#define RX_DATA_LEN     8
#define TX_DATA_LEN     5
typedef enum{
    WHEEL_OD_IS_16INCH = 0,
    WHEEL_OD_IS_18INCH = 1,
    WHEEL_OD_IS_20INCH = 2,
    WHEEL_OD_IS_22INCH = 3,
    WHEEL_OD_IS_24INCH = 4,
    WHEEL_OD_IS_26INCH = 5,
    WHEEL_OD_IS_700C = 6,
    WHEEL_OD_IS_28INCH = 7,
    WHEEL_OD_IS_EXTRA = 8,
}wheelod_st;

typedef union
{
    unsigned char data1Val;
    struct{
        unsigned char is_assist_level:6;	// bit5～0：助力档位0-5。0 档为空档表示无助力，1-5 档表示5 档助力
        unsigned char is_push_on:1;         // bit6: 1 推行模式即6KM/H ，0 正常助力模式；
        unsigned char is_light_on:1;		// bit7: 1 开大灯，0 关大灯?
    }data1Bits;
}data1_ST;

typedef union
{
    unsigned char data2Val;
    struct{
        unsigned char wheel_od:3;		// bit2～0:轮径值0-7。
        unsigned char speed_limit:5;	// bit7～3:限速值0-28。
    }data2Bits;
}data2_ST;

typedef struct
{
    data1_ST data1;
    data2_ST data2;
}ctrlData_st;

typedef struct{
    UInt8 sop;	//
    UInt8 data1;
    UInt8 data2;
    UInt8 chksum;	//data1,data2,0x0E 异或校验值
    UInt8 eop;
}uart_tx_packet;	// 5 BYTE

//RX STRUCTURE ////////////////////////////////////////////////////
typedef struct{
    UInt8 is_handlebar_err:1;	// bit0：转把故障
    UInt8 is_brake:1;			// bit1：刹车
    UInt8 is_motor_err:1;		// bit2：电机故障
    UInt8 is_sleep:1;			// bit3：休眠
    UInt8 reserved:4;           //bit7～4:保留
}controller_state_ST;

typedef struct{
    UInt8 sop;          // 0x41： 起始标志
    UInt8 vol_h;		// data1:  实际电压值高字节
    UInt8 vol_l;		// data2:  实际电压值低字节,单位0.1V
    UInt8 current;      // data3:  实时电流值0x01 表示0.3A
    UInt8 speed_h;      // data4:  实时速度值高字节
    UInt8 speed_l;      // data5:  实时速度值低字节,单位0.1KM/H
    controller_state_ST ctrl_state;		// data6:  bit7～0:控制器状态代码; 1 表示状态有效，0 表示状态无效
    UInt8 chksum;       //data1~data6 异或校验值
}uart_rx_packet;


#endif /* CommProtocolDmhc1v5_h */
